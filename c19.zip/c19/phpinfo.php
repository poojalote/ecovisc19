<?php echo phpinfo();?>
